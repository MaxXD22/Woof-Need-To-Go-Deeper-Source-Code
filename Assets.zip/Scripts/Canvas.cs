﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Canvas : MonoBehaviour
{
    public Text roundText;
    public Text timeText;

    public Text p1Points;
    public Text p2Points;

    public GameObject bones;
    public GameObject pause;
    public GameObject hideAndSeekInfoImage;
    public GameObject hideAndSeekInfoHideP1;
    public GameObject hideAndSeekInfoHideP2;
    public GameObject hideAndSeekInfoFindP1;
    public GameObject hideAndSeekInfoFindP2;
    public GameObject hideAndSeekInvalid;
    public GameObject hideAndSeekHouse;

    public Animator hideAndSeekInfoAnim;

    public Text p1Bones;
    public Text p2Bones;

    public bool canPause;

    public Animator transitionAnim;

    GameManager gameMana;

    IEnumerator Start()
    {
        roundText.text = "";
        gameMana = FindObjectOfType<GameManager>();

        yield return null;

        if(gameMana.mode == GameMode.FindBone)
        {
            roundText.text = "Bone finders - Round " + (GameManager.round + 1).ToString() + "/" + MainMenu.rounds.ToString(); 
        }
        else if (gameMana.mode == GameMode.HideAndSeek)
        {
            hideAndSeekInfoImage.SetActive(true);
            if (gameMana.nowSeeking)
            {
                roundText.text = "Hide and seek (Seeking) - Round " + (GameManager.round + 1).ToString() + "/" + MainMenu.rounds.ToString();
                if(GameManager.hideAndSeekBone == 1)
                {
                    hideAndSeekInfoFindP2.SetActive(true);
                }
                else
                {
                    hideAndSeekInfoFindP1.SetActive(true);
                }
            }
            else
            {
                roundText.text = "Hide and seek (Hiding) - Round " + (GameManager.round + 1).ToString() + "/" + MainMenu.rounds.ToString();

                if(gameMana.hider == 1)
                {
                    hideAndSeekInfoHideP1.SetActive(true);
                }
                else
                {
                    hideAndSeekInfoHideP2.SetActive(true);
                }
            }
        }
        else if (gameMana.mode == GameMode.Infinite)
        {
            bones.SetActive(true);
            roundText.text = "Bone frenzy - Round " + (GameManager.round + 1).ToString() + "/" + MainMenu.rounds.ToString();
        }
    }

    void Update()
    {
        if(gameMana.mode == GameMode.HideAndSeek)
        {
            if (gameMana.nowSeeking)
            {
                timeText.text = "Time: " + (gameMana.seekTime - gameMana.time).ToString();
            }
            else
            {
                timeText.text = "Time: " + gameMana.time.ToString();
            }
        }
        else
        {
            timeText.text = "Time: " + gameMana.time.ToString();
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if(Time.timeScale == 1 && canPause)
            {
                pause.SetActive(true);
                Time.timeScale = 0;
            } else if(Time.timeScale == 0 && canPause)
            {
                pause.SetActive(false);
                Time.timeScale = 1;
            }
        }

        p1Points.text = GameManager.p1Points.ToString();
        p2Points.text = GameManager.p2Points.ToString();

        p1Bones.text = gameMana.p1Bones.ToString();
        p2Bones.text = gameMana.p2Bones.ToString();
    }

    public IEnumerator InvalidBone()
    {
        hideAndSeekInfoAnim.SetTrigger("Invalid");
        hideAndSeekInfoHideP1.SetActive(false);
        hideAndSeekInfoHideP2.SetActive(false);

        hideAndSeekInvalid.SetActive(true);

        yield return null;

        hideAndSeekInfoAnim.ResetTrigger("Invalid");

        yield return new WaitForSeconds(5);

        hideAndSeekInvalid.SetActive(false);
        if (gameMana.hider == 1)
        {
            hideAndSeekInfoHideP1.SetActive(true);
        }
        else
        {
            hideAndSeekInfoHideP2.SetActive(true);
        }
    }

    public IEnumerator House()
    {
        hideAndSeekInfoAnim.SetTrigger("Invalid");
        hideAndSeekInfoFindP1.SetActive(false);
        hideAndSeekInfoFindP2.SetActive(false);

        hideAndSeekHouse.SetActive(true);

        yield return null;

        hideAndSeekInfoAnim.ResetTrigger("Invalid");
    }

    public void Resume()
    {
        if (canPause)
        {
            pause.SetActive(false);
            Time.timeScale = 1;
        }
    }

    public void Quit()
    {
        canPause = false;
        StartCoroutine(ExitGame());
    }

    IEnumerator ExitGame()
    {
        transitionAnim.SetTrigger("Fade");
        yield return new WaitForSecondsRealtime(2);
        Time.timeScale = 1;
        SceneManager.LoadScene("MainMenu");
    }
}
