﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class DogController : MonoBehaviour
{
    [Range(1,3)]
    public int playerNum = 1;

    public float moveSpeed = 3;
    public float runSpeed = 5;
    public float jumpForce = 5;

    public bool running;
    public bool isGrounded;
    public bool grabbingBone;
    public bool digging;

    public Transform feet;
    public GameObject[] digSpots;
    public GameObject bone;
    public Transform sprite;
    public Transform boneHandle;

    public LayerMask mask;

    public Grid grid;
    public Tilemap tm;

    public int spriteScaleMultiplier = 1;

    public int standingOn = 0; //0= Stone; 1= Sand; 2= Dirt;
    public GameObject[] digParticles;

    public DogController riding;

    [Range(0, 10)]
    public float stamina = 10;

    public Animator anim;

    public AudioClip[] barkSounds;
    public AudioClip boneGrab;
    public AudioClip bonePlace;
    public AudioClip boneSteal;
    public AudioClip boneStore;
    public AudioClip jump;

    float idleElapsed;

    Rigidbody2D rb2D;
    AudioSource audioS;

    GameManager gameMana;

    void Start()
    {
        rb2D = GetComponent<Rigidbody2D>();
        audioS = GetComponent<AudioSource>();
        gameMana = FindObjectOfType<GameManager>();

        spriteScaleMultiplier = 1;
    }

    void Update()
    {
        CheckTopDog();

        var movement = (playerNum == 1) ? Input.GetAxisRaw("Horizontal") : Input.GetAxisRaw("HorizontalP2");
        var movementAnim = (playerNum == 1) ? Input.GetAxisRaw("Horizontal") : Input.GetAxisRaw("HorizontalP2");
        running = (playerNum == 1) ? Input.GetKey(KeyCode.LeftShift) : Input.GetKey(KeyCode.Space);

        idleElapsed += Time.deltaTime;

        digging = false;
        anim.SetFloat("Digging", 0);
        if (movement != 0 && Time.timeScale == 1)
        {
            spriteScaleMultiplier = (int)movement;
            idleElapsed = 0;
        }
        else
        {
            if(isGrounded && ((playerNum == 1) ? Input.GetKey(KeyCode.S) : Input.GetKey(KeyCode.DownArrow)) && Time.timeScale == 1){
                idleElapsed = 0;
                digging = true;
                anim.SetFloat("Digging", 1);
            }
        }

        sprite.localScale = new Vector3((Mathf.Abs(sprite.localScale.x)) * spriteScaleMultiplier, sprite.localScale.y, sprite.localScale.z);

        if (running)
        {
            if (Time.timeScale == 1)
            {
                idleElapsed = 0;

                //transform.position += new Vector3(movement, 0, 0) * Time.deltaTime * runSpeed; rb.velocity = movement.normalized * moveSpeed + new Vector3(0.0f, rb.velocity.y, 0.0f);
                // rb2D.velocity = new Vector2(1 * movement * runSpeed * Time.deltaTime, rb2D.velocity.y);

                Vector2 mv = new Vector2(1 * movement * runSpeed * Time.deltaTime, 0);
                rb2D.velocity = mv.normalized * runSpeed + new Vector2(0.0f, rb2D.velocity.y);
                anim.SetFloat("Speed", Mathf.Abs(movementAnim * 2));
            }
        }
        else
        {
            if (Time.timeScale == 1) {
                //transform.position += new Vector3(movement, 0, 0) * Time.deltaTime * moveSpeed;
                //transform.position += new Vector3(movement, 0, 0) * Time.deltaTime * runSpeed; rb.velocity = movement.normalized * moveSpeed + new Vector3(0.0f, rb.velocity.y, 0.0f);
                //rb2D.velocity = Vector2.right * movement * moveSpeed * Time.deltaTime;

                Vector2 mv = new Vector2(1 * movement * moveSpeed * Time.deltaTime, 0);
                rb2D.velocity = mv.normalized * moveSpeed + new Vector2(0.0f, rb2D.velocity.y);

                anim.SetFloat("Speed", Mathf.Abs(movementAnim));
            }
        }

        if (((playerNum == 1) ? Input.GetKeyDown(KeyCode.W) : Input.GetKeyDown(KeyCode.UpArrow)) && isGrounded && !digging)
        {
            if (Time.timeScale == 1)
            {
                idleElapsed = 0;
                rb2D.AddForce(new Vector2(0, jumpForce), ForceMode2D.Impulse);

                audioS.PlayOneShot(jump);
            }
        }

        if ((playerNum == 1) ? Input.GetKeyDown(KeyCode.LeftControl) : Input.GetKeyDown(KeyCode.RightControl))
        {
            if (Time.timeScale == 1)
            {
                idleElapsed = 0;
                anim.SetTrigger("Bark");

                audioS.PlayOneShot(barkSounds[Random.Range(0, barkSounds.Length)]);

                if (isGrounded)
                {
                    rb2D.AddForce(new Vector2(0, 3), ForceMode2D.Impulse);
                }

                DogController[] controllers = FindObjectsOfType<DogController>();
                foreach (DogController controller in controllers)
                {
                    controller.WakeUp();
                }
            }
        }

        anim.SetFloat("IdleElapsed", idleElapsed);

        foreach (GameObject ds in digSpots)
        {
            ds.SetActive(digging);
        }

        for (int i = 0; i < digParticles.Length; i++)
        {
            if(i == standingOn)
            {
                digParticles[i].SetActive(true);
            }
            else
            {
                digParticles[i].SetActive(false);
            }
        }
    }

    void FixedUpdate()
    {
        isGrounded = false;
        Collider2D[] colliders = Physics2D.OverlapCircleAll(feet.position, 0.1f);
        for (int i = 0; i < colliders.Length; i++)
        {
            if (colliders[i].gameObject != gameObject)
            {
                isGrounded = true;

                if(colliders[i].name == "TilemapG")
                {
                    standingOn = 0;
                } else if (colliders[i].name == "TilemapS")
                {
                    standingOn = 1;
                }
                else if (colliders[i].name == "TilemapD")
                {
                    standingOn = 2;
                } else if (colliders[i].name.Contains("Dog"))
                {
                    standingOn = 3;
                }
            }
        }

        anim.SetBool("isGrounded", isGrounded);
    }

    public void WakeUp()
    {
        if (isGrounded && idleElapsed >= 20)
        {
            idleElapsed = 0;
            rb2D.AddForce(new Vector2(0, 3), ForceMode2D.Impulse);
        }

        idleElapsed = 0;
    }

    void CheckTopDog()
    {
        //var layerMask = ~((1 << 8) | (1 << 9) | (1 << 10));
        RaycastHit2D[] hits = Physics2D.CircleCastAll(digSpots[0].transform.position, 1f, -Vector2.up, 1f);

        if(hits.Length == 0)
        {
            return;
        }

        for (int i = 0; i < hits.Length; i++)
        {
            RaycastHit2D hit = hits[i];

            DogController controller = hit.collider.GetComponent<DogController>();
            if (controller != null && controller != this)
            {
                controller.riding = this;

                if (digging && !grabbingBone)
                {
                    controller.StartCoroutine(controller.GetAttacked(this));
                }
            }
        }
    }

    public IEnumerator GetAttacked(DogController whoAttacked)
    {
        if (grabbingBone)
        {
            audioS.PlayOneShot(boneSteal);
            audioS.PlayOneShot(boneGrab);

            grabbingBone = false;

            whoAttacked.grabbingBone = true;
            whoAttacked.bone = bone;

            bone.transform.SetParent(whoAttacked.boneHandle);
            bone.transform.localPosition = Vector3.zero;
            bone.transform.localRotation = Quaternion.Euler(Vector3.zero);

            grabbingBone = false;

            yield return null;
        }
    }

    public void GrabHideAndSeekBone(GameObject _bone)
    {
        grabbingBone = true;

        bone = _bone;

        _bone.transform.SetParent(boneHandle);
        _bone.transform.localPosition = Vector3.zero;
        _bone.transform.localRotation = Quaternion.Euler(Vector3.zero);
    }

    IEnumerator OnTriggerEnter2D(Collider2D col)
    {
        yield return null;
        if (gameMana != null)
        {
            if (gameMana.mode == GameMode.HideAndSeek && playerNum == GameManager.hideAndSeekBone)
            {
                yield break;
            }
        }

        if (col.gameObject.CompareTag("Bone") && !grabbingBone)
        {
            audioS.PlayOneShot(boneGrab);

            bone = col.gameObject;
            grabbingBone = true;

            Collider2D[] cols2D = col.GetComponents<Collider2D>();
            foreach (Collider2D col2D in cols2D)
            {
                col2D.enabled = false;
            }

            //Rigidbody2D r2 = col.GetComponent<Rigidbody2D>();
            //r2.isKinematic = true;
            //r2.gravityScale = 0;

            col.transform.SetParent(boneHandle);
            col.transform.localPosition = Vector3.zero;
            col.transform.localRotation = Quaternion.Euler(Vector3.zero);

            if(MainMenu.seekGoal == 1)
            {
                gameMana.winner = playerNum;
                if(playerNum == 1)
                {
                    GameManager.p1Points++;
                }
                else
                {
                    GameManager.p2Points++;
                }
                gameMana.EndRound();
            }
            else
            {
                FindObjectOfType<Canvas>().StartCoroutine(FindObjectOfType<Canvas>().House());
            }
        }
    }

    public void LetGoInfinite()
    {
        audioS.PlayOneShot(boneStore);
        grabbingBone = false;

        Destroy(bone);

        grabbingBone = false;
    }

    public IEnumerator FadeOut(float FadeTime)
    {
        float startVolume = audioS.volume;

        while (audioS.volume > 0)
        {
            audioS.volume -= startVolume * Time.deltaTime / FadeTime;

            yield return null;
        }

        audioS.Stop();
        audioS.volume = 0;
    }
}
