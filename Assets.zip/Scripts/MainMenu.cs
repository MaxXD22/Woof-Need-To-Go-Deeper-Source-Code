﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public GameObject boneFind;
    public GameObject hideAndSeek;
    public GameObject infinite;

    public GameObject quitJokeThreat;
    public GameObject music;

    public Animator anim;
    public Animator transitionAnim;

    public int[] roundValues = new int[] { 1, 5, 10, 15, 20, 30, 50 };
    public static string mode = "FindBone";
    public static int rounds = 0;
    public static int hider = 0; //0 -> one each; 1-> P1; 2-> P2; 3-> Random
    public static int seekTime = 0; //0 -> Twice; 1-> Thrice; 2-> Four times; 3-> Same; 4-> Infinite
    public static int boneRate = 0; //0 -> 10s; 1-> 5s; 2-> 20s; 3-> All at start; 4-> Randomly; 5-> When scored
    public static int seekGoal = 0; //0 -> Find and return; 1-> Only find;

    public AudioClip playClip;

    void Start()
    {
        Time.timeScale = 1;
        Rounds(0);
        Hider(0);
        SeekTime(0);
        SeekGoal(0);
        BoneRate(0);
        BoneFind();

        mode = "FindBone";

        GameManager.round = 0;
        GameManager.p1Points = 0;
        GameManager.p2Points = 0;
        GameManager.p3Points = 0;
        GameManager.results = 0;
    }

    public void BeginGame()
    {
        StartCoroutine(StartGameC());
    }

    public void BoneFind()
    {
        mode = "FindBone";
        boneFind.SetActive(true);
        hideAndSeek.SetActive(false);
        infinite.SetActive(false);
    }

    public void HideAndSeek()
    {
        mode = "HideAndSeek";
        boneFind.SetActive(false);
        hideAndSeek.SetActive(true);
        infinite.SetActive(false);
    }

    public void Infinite()
    {
        mode = "Infinite";
        boneFind.SetActive(false);
        hideAndSeek.SetActive(false);
        infinite.SetActive(true);
    }

    public void Modes()
    {
        anim.SetTrigger("Modes");
        anim.ResetTrigger("Back");
        anim.ResetTrigger("Instructions");
        anim.ResetTrigger("HowToPlay");
    }

    public void ModeInstructions()
    {
        anim.SetTrigger("Instructions");
        anim.ResetTrigger("Modes");
        anim.ResetTrigger("Back");
        anim.ResetTrigger("HowToPlay");
    }

    public void Back()
    {
        anim.SetTrigger("Back");
        anim.ResetTrigger("Modes");
        anim.ResetTrigger("Instructions");
        anim.ResetTrigger("HowToPlay");
    }

    public void HowToPlay()
    {
        anim.ResetTrigger("Back");
        anim.ResetTrigger("Modes");
        anim.ResetTrigger("Instructions");
        anim.SetTrigger("HowToPlay");
    }

    public void Quit()
    {
        GetComponent<AudioSource>().Pause();
        Time.timeScale = 0;
        quitJokeThreat.SetActive(true);
    }

    public void QuitJoke()
    {
        GetComponent<AudioSource>().UnPause();
        Time.timeScale = 1;
        quitJokeThreat.SetActive(false);
    }

    public void Rounds(int round)
    {
        rounds = roundValues[round];
    }

    public void Hider(int _hider)
    {
        hider = _hider;
    }

    public void SeekTime(int _seekTIme)
    {
        seekTime = _seekTIme;
    }

    public void SeekGoal(int _seekGoal)
    {
        seekGoal = _seekGoal;
    }

    public void BoneRate(int _boneRate)
    {
        boneRate = _boneRate;
    }

    IEnumerator StartGameC()
    {
        GetComponent<AudioSource>().PlayOneShot(playClip);
        transitionAnim.SetTrigger("Fade");
        yield return new WaitForSeconds(2);
        SceneManager.LoadScene("Game");
    }
}
