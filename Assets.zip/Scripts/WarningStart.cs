﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WarningStart : MonoBehaviour
{
    public Animator anim;

    public GameObject music;

    IEnumerator Start()
    {
        yield return new WaitUntil(() => Input.anyKeyDown);

        anim.SetTrigger("Fade");

        yield return new WaitForSeconds(1);

        music.SetActive(true);
        DontDestroyOnLoad(music);

        SceneManager.LoadScene("MainMenu");
    }

    void Update()
    {
        
    }
}
