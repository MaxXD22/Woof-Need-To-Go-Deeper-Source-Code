﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public GameMode mode;

    public bool specificLevel = false;
    public int levelToLoad = 0;

    public int time;
    public int seekTime;
    public int bonesToFind;

    public List<GameObject> levels;
    public Level currentLevel;

    public GameObject dog1;
    public GameObject dog2;
    public GameObject dog3;

    public static int round;
    public static int p1Points;
    public static int p2Points;
    public static int p3Points;

    public int p1Bones;
    public int p2Bones;
    public int p3Bones;

    public int winner;

    [Header("Hide And Seek")]
    [Range(1,3)]
    public int hider = 1;
    public static bool seeking;
    public static Vector3 bonePos;
    public static int mapHideAndSeek;
    public static int hideAndSeekBone;
    public static int hideAndSeekTime;
    public static int results;
    public bool nowSeeking;

    public GameObject p1Bone;
    public GameObject p2Bone;
    public GameObject p3Bone;

    public bool finishedRound;
    public bool hasHiddenBone;

    public Animator transitionAnim;

    float elapsed;

    AudioSource audioS;
    public AudioClip spawnBoneS;
    public AudioClip placeBoneS;
    public AudioClip endRoundS;

    IEnumerator Start()
    {
        finishedRound = false;
        hasHiddenBone = false;
        mode = (GameMode) Enum.Parse(typeof(GameMode), MainMenu.mode);
        nowSeeking = seeking;

        p1Bones = 0;
        p2Bones = 0;
        p3Bones = 0;

        audioS = GetComponent<AudioSource>();

        foreach (GameObject level in levels)
        {
            level.SetActive(false);
        }

        if(mode == GameMode.HideAndSeek && seeking)
        {
            levels[mapHideAndSeek].SetActive(true);
            currentLevel = levels[mapHideAndSeek].GetComponent<Level>();
            currentLevel.StartCoroutine(currentLevel.LoadLevel());
        
            if(MainMenu.seekTime == 0)
            {
                seekTime = hideAndSeekTime * 2;
            } else if (MainMenu.seekTime == 1)
            {
                seekTime = hideAndSeekTime * 3;
            }
            else if (MainMenu.seekTime == 2)
            {
                seekTime = hideAndSeekTime * 4;
            }
            else if (MainMenu.seekTime == 3)
            {
                seekTime = hideAndSeekTime;
            }
            else if (MainMenu.seekTime == 4)
            {
                seekTime = 1000000000;
            }
        }
        else
        {
            if (specificLevel)
            {
                levels[levelToLoad].SetActive(true);
                currentLevel = levels[levelToLoad].GetComponent<Level>();
                currentLevel.StartCoroutine(currentLevel.LoadLevel());
            }
            else
            {
                int r = UnityEngine.Random.Range(0, levels.Count);
                levelToLoad = r;
                currentLevel = levels[r].GetComponent<Level>();

                levels[r].SetActive(true);
                currentLevel.StartCoroutine(currentLevel.LoadLevel());
            }
        }

        yield return null;

        if (mode == GameMode.FindBone || mode == GameMode.Infinite)
        {
            dog1.SetActive(true);
            dog2.SetActive(true);
        } else if (mode == GameMode.HideAndSeek)
        {
            if (seeking)
            {
                Vector3 p1Pos = dog1.transform.position;
                Vector3 p2Pos = dog2.transform.position;

                dog1.SetActive(true);
                dog2.SetActive(true);

                //dog1.transform.position = p2Pos;
                //dog2.transform.position = p1Pos;

                if(hideAndSeekBone == 1)
                {
                    GameObject GO = Instantiate(p1Bone, bonePos, Quaternion.identity);
                } else if (hideAndSeekBone == 2)
                {
                    GameObject GO = Instantiate(p2Bone, bonePos, Quaternion.identity);
                }
                else if (hideAndSeekBone == 3)
                {
                    GameObject GO = Instantiate(p3Bone, bonePos, Quaternion.identity);
                }
            }
            else
            {
                FindObjectOfType<Canvas>().canPause = false;

                if (MainMenu.hider == 0)
                {
                    if(round == 0 || round % 2 == 0)
                    {
                        hider = 1;
                    }
                    else
                    {
                        hider = 2;
                    }
                } else if (MainMenu.hider == 1)
                {
                    hider = 1;
                } else if (MainMenu.hider == 2)
                {
                    hider = 2;
                }
                else if (MainMenu.hider == 3)
                {
                    hider = UnityEngine.Random.Range(1, 3);
                }

                hideAndSeekBone = hider;
                mapHideAndSeek = levelToLoad;
                if(hider == 1)
                {
                    dog1.SetActive(true);
                    GameObject GO = Instantiate(p1Bone);
                    dog1.GetComponent<DogController>().GrabHideAndSeekBone(GO);

                    while (!hasHiddenBone)
                    {
                        yield return new WaitUntil(() => Input.GetKeyDown(KeyCode.LeftControl) || Input.GetKeyDown(KeyCode.Return));

                        if (time != 0)
                        {
                            bonePos = GO.transform.position;
                            currentLevel.diggings[0].CheckBoneCoordinate(bonePos);
                        }
                    }

                    Time.timeScale = 0;
                    transitionAnim.SetTrigger("Fade");

                    audioS.PlayOneShot(placeBoneS);
                    hideAndSeekTime = time;
                    yield return null;

                    seeking = true;

                    yield return new WaitForSecondsRealtime(2);

                    Time.timeScale = 1;
                    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

                    yield break;

                } else if (hider == 2)
                {
                    dog2.SetActive(true);
                    GameObject GO = Instantiate(p2Bone);
                    dog2.GetComponent<DogController>().GrabHideAndSeekBone(GO);

                    while (!hasHiddenBone)
                    {
                        yield return new WaitUntil(() => Input.GetKeyDown(KeyCode.RightControl) || Input.GetKeyDown(KeyCode.Return));

                        if(time != 0)
                        {
                            bonePos = GO.transform.position;
                            currentLevel.diggings[0].CheckBoneCoordinate(bonePos);
                        }
                    }

                    Time.timeScale = 0;
                    transitionAnim.SetTrigger("Fade");

                    audioS.PlayOneShot(placeBoneS);
                    hideAndSeekTime = time;
                    yield return null;

                    seeking = true;

                    yield return new WaitForSecondsRealtime(2);

                    Time.timeScale = 1;
                    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

                    yield break;
                }
                else if (hider == 3)
                {
                    dog3.SetActive(true);
                    GameObject GO = Instantiate(p3Bone);
                    dog3.GetComponent<DogController>().GrabHideAndSeekBone(GO);

                    yield return new WaitUntil(() => Input.GetKeyDown(KeyCode.RightControl) || Input.GetKeyDown(KeyCode.Return));

                    bonePos = GO.transform.position;

                    hideAndSeekTime = time;
                    yield return null;

                    seeking = true;
                    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

                    yield break;
                }
            }
        }

        if (mode == GameMode.Infinite)
        {
            if (MainMenu.boneRate == 0)
            {
                InvokeRepeating("SpawnInfiniteBone", 10, 10);
            }
            else if (MainMenu.boneRate == 1)
            {
                InvokeRepeating("SpawnInfiniteBone", 5, 5);
            }
            else if (MainMenu.boneRate == 2)
            {
                InvokeRepeating("SpawnInfiniteBone", 20, 20);
            }
            else if (MainMenu.boneRate == 4)
            {
                InvokeRepeating("SpawnInfiniteBone", UnityEngine.Random.Range(5,20), UnityEngine.Random.Range(5, 20));
            }
        }

        seeking = false;
    }

    void Update()
    {
        elapsed += Time.deltaTime;
        if(elapsed >= 1 && !finishedRound)
        {
            elapsed = 0;
            time++;

            if(mode == GameMode.HideAndSeek)
            {
                if (nowSeeking)
                {
                    if(time == seekTime)
                    {
                        if(hideAndSeekBone == 1)
                        {
                            p1Points++;
                            winner = 1;
                        }
                        else
                        {
                            p2Points++;
                            winner = 2;
                        }
                        EndRound();
                    }
                }
            }
        }
    }

    void SpawnInfiniteBone()
    {
        if (currentLevel.bonePos.Count > 0)
        {
            audioS.PlayOneShot(spawnBoneS);
        }
        currentLevel.InstantiateBone();
    }

    public void EndRound()
    {
        FindObjectOfType<Canvas>().canPause = false;
        finishedRound = true;

        if(mode == GameMode.Infinite)
        {
            if(p1Bones > p2Bones)
            {
                p1Points++;
                winner = 1;
            }
            else if(p1Bones < p2Bones)
            {
                p2Points++;
                winner = 2;
            }
            else if(p1Bones == p2Bones)
            {

            }
        }

        round++;

        StartCoroutine(EndRoundZoom());
    }

    IEnumerator EndRoundZoom()
    {
        if(winner == 1)
        {
            FindObjectOfType<CameraFollow>().targets.Remove(dog2.transform);
            audioS.PlayOneShot(endRoundS);
        } else if(winner == 2)
        {
            FindObjectOfType<CameraFollow>().targets.Remove(dog1.transform);
            audioS.PlayOneShot(endRoundS);
        }

        yield return new WaitForSeconds(1.75f);

        transitionAnim.SetTrigger("Fade");

        yield return new WaitForSeconds(1f);

        dog1.GetComponent<DogController>().StartCoroutine(dog1.GetComponent<DogController>().FadeOut(.25f));
        dog2.GetComponent<DogController>().StartCoroutine(dog2.GetComponent<DogController>().FadeOut(.25f));

        yield return new WaitForSeconds(.75f);

        if (round >= MainMenu.rounds)
        {
            if(p1Points > p2Points)
            {
                results = 1;
            } else if (p2Points > p1Points)
            {
                results = 2;
            } else if (p2Points == p1Points)
            {
                results = 4;
            }

            SceneManager.LoadScene("Results");
        }
        else
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}

public enum GameMode { FindBone, HideAndSeek, Infinite }
