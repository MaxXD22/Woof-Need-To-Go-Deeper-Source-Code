﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Digging : MonoBehaviour
{
    public Grid grid;
    public Grid gridStone;
    public Grid gridDirt;
    public Tilemap tm;
    public Tilemap tmStone;
    public Tilemap tmDirt;

    public TileBase stoneTile;

    public Animator anim;
    public AudioSource audioS;

    public AudioClip[] clips;

    public DogController controller;

    float elapsed;

    void Start()
    {
        elapsed = 0;
    }

    void Update()
    {
        elapsed += Time.deltaTime;

        if (elapsed >= 0.5f)
        {
            elapsed = Random.Range(0f, 0.3f);
            Vector3Int coordinate = grid.WorldToCell(transform.position);
            coordinate.z = 0;
            tm.SetTile(coordinate, null);

            Vector3Int coordinateDirt = gridDirt.WorldToCell(transform.position);
            coordinateDirt.z = 0;
            tmDirt.SetTile(coordinateDirt, null);

            audioS.PlayOneShot(clips[controller.standingOn]);
            anim.SetFloat("Digging", 1);
        }
    }

    public void CheckBoneCoordinate(Vector3 bonePos)
    {
        Vector3Int coordinate = grid.WorldToCell(bonePos);
        coordinate.z = 0;
        var tilemapTile = tmStone.GetTile(coordinate);

        if(tilemapTile == stoneTile)
        {
            FindObjectOfType<Canvas>().StartCoroutine(FindObjectOfType<Canvas>().InvalidBone());
        }
        else
        {
            FindObjectOfType<GameManager>().hasHiddenBone = true;
        }
    }
}
