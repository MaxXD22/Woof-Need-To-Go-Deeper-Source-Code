﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DogHouse : MonoBehaviour
{
    public int player;

    GameManager gameMana;

    void Start()
    {
        gameMana = FindObjectOfType<GameManager>();
    }

    void Update()
    {
        
    }

    IEnumerator OnTriggerEnter2D(Collider2D col)
    {
        DogController controller = col.gameObject.GetComponent<DogController>();
        yield return null;
        if (controller != null)
        {
            if (gameMana.mode == GameMode.FindBone)
            {
                if (controller.playerNum == player && controller.grabbingBone && !gameMana.finishedRound)
                {
                    controller.LetGoInfinite();
                    if (player == 1)
                    {
                        GameManager.p1Points++;
                        gameMana.winner = 1;
                    }
                    else if(player == 2)
                    {
                        GameManager.p2Points++;
                        gameMana.winner = 2;
                    }
                    else if (player == 3)
                    {
                        GameManager.p3Points++;
                        gameMana.winner = 3;
                    }

                    gameMana.EndRound();
                    Debug.Log("Okay, player " + player.ToString() + " wins!");
                }
            } else if (gameMana.mode == GameMode.Infinite)
            {
                if (controller.playerNum == player && controller.grabbingBone && !gameMana.finishedRound)
                {
                    controller.LetGoInfinite();
                    gameMana.bonesToFind--;
                    if (player == 1)
                    {
                        gameMana.p1Bones++;
                    }
                    else if (player == 2)
                    {
                        gameMana.p2Bones++;
                    }
                    else if (player == 3)
                    {
                        gameMana.p3Bones++;
                    }

                    if (gameMana.bonesToFind == 0)
                    {
                        gameMana.EndRound();
                    }

                    if(MainMenu.boneRate == 5)
                    {
                        gameMana.currentLevel.InstantiateBone();
                    }
                    Debug.Log("Okay, player " + player.ToString() + " gets one point!");
                }
            } else if (gameMana.mode == GameMode.HideAndSeek)
            {
                if (gameMana.nowSeeking && controller.grabbingBone && controller.playerNum != GameManager.hideAndSeekBone && !gameMana.finishedRound && MainMenu.seekGoal == 0)
                {
                    controller.LetGoInfinite();
                    if (controller.playerNum == 1)
                    {
                        GameManager.p1Points++;
                        gameMana.winner = 1;
                    }
                    else
                    {
                        GameManager.p2Points++;
                        gameMana.winner = 2;
                    }
                    gameMana.EndRound();
                    // Debug.Log("Okay, player " + player.ToString() + " has found the bone!");
                }
            }
        }
    }
}
