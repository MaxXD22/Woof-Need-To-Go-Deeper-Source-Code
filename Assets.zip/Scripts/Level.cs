﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Level : MonoBehaviour
{
    public Grid sandGrid;
    public Grid dirtGrid;
    public Grid stoneGrid;
    public Tilemap sandTm;
    public Tilemap dirtTm;
    public Tilemap stoneTm;

    public GameObject bone;
    public List<Transform> bonePos;

    public Digging[] diggings;

    GameManager gameMana;

    void Start()
    {
        // LoadLevel();

    }

    void Update()
    {

    }

    public IEnumerator LoadLevel()
    {
        gameMana = FindObjectOfType<GameManager>();

        yield return null;

        if(gameMana.mode == GameMode.FindBone)
        {
            InstantiateBone();
        } else if(gameMana.mode == GameMode.Infinite)
        {
            gameMana.bonesToFind = bonePos.Count;
            if(MainMenu.boneRate == 0)
            {
                InstantiateBone();
            } else if(MainMenu.boneRate == 1)
            {
                InstantiateBone();
            } else if(MainMenu.boneRate == 2)
            {
                InstantiateBone();
            } else if(MainMenu.boneRate == 3)
            {
                int c = bonePos.Count;
                while(c > 0)
                {
                    InstantiateBone();
                    c--;
                }
            } else if (MainMenu.boneRate == 4)
            {
                InstantiateBone();
            } else if(MainMenu.boneRate == 5)
            {
                InstantiateBone();
            }
        }

        yield return null;

        foreach (Digging digging in diggings)
        {
            digging.grid = sandGrid;
            digging.gridDirt = dirtGrid;
            digging.gridStone = stoneGrid;
            digging.tm = sandTm;
            digging.tmDirt = dirtTm;
            digging.tmStone = stoneTm;
        }
    }

    public void InstantiateBone()
    {
        if (bonePos.Count > 0)
        {
            int r = Random.Range(0, bonePos.Count);
            Transform bP = bonePos[r];
            Instantiate(bone, bP.position, Quaternion.identity);

            bonePos.Remove(bonePos[r]);
        }
    }
}
