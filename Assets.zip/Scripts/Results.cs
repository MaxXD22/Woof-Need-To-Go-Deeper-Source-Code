﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Results : MonoBehaviour
{
    public GameObject goldenBone;

    public DogController dog1;
    public DogController dog2;
    public DogController dog3;

    public Text text;
    public Text pointsText;

    public Animator transitionAnim;

    public GameObject[] confetti;

    IEnumerator Start()
    {
        if(GameManager.results == 1)
        {
            GameObject GO = Instantiate(goldenBone);
            dog1.GrabHideAndSeekBone(GO);

            text.text = "Player 1 won!";
            text.color = Color.red;
        } else if(GameManager.results == 2)
        {
            GameObject GO = Instantiate(goldenBone);
            dog2.GrabHideAndSeekBone(GO);

            text.text = "Player 2 won!";
            text.color = Color.blue;
        } else if(GameManager.results == 3)
        {
            GameObject GO = Instantiate(goldenBone);
            dog3.GrabHideAndSeekBone(GO);

            text.text = "Player 3 won!";
            text.color = Color.green;
        } else if(GameManager.results == 4)
        {
            text.text = "Tie...";
            text.color = Color.black;

            foreach (GameObject conf in confetti)
            {
                conf.SetActive(false);
            }
        }
        else
        {
            text.text = "Tie...";
            text.color = Color.black;

            foreach (GameObject conf in confetti)
            {
                conf.SetActive(false);
            }
        }

        pointsText.text = GameManager.p1Points.ToString() + " - " + GameManager.p2Points.ToString();

        yield return null;

        dog2.spriteScaleMultiplier = -1;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            StartCoroutine(Quit());
        }
    }

    IEnumerator Quit()
    {
        transitionAnim.SetTrigger("Fade");

        yield return new WaitForSeconds(1f);

        dog1.StartCoroutine(dog1.FadeOut(.25f));
        dog2.StartCoroutine(dog2.FadeOut(.25f));

        yield return new WaitForSeconds(.75f);

        SceneManager.LoadScene("MainMenu");
    }
}
